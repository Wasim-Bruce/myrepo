package chatserver;

import java.io.*;
import java.net.*;

public class ConnToInfo {
	
	Socket s;
	DataInputStream disTo;
	DataOutputStream dosTo;
	String ipStrTo;

}
